# How to Configure Virtual Host on Windows 10

https://www.cloudways.com/blog/configure-virtual-host-on-windows-10-for-wordpress/

C:\xampp\apache\conf\extra\httpd-vhosts.conf

C:\Windows\System32\drivers\etc\hosts
